from setuptools import setup

setup(
    name='formulas',
    version='1.0',
    description='Este programa tiene dos  funciones de formulas, uno genera la presión y el otro la caudal',
    author='CHK',
    author_email='clarens53@gmail.com',
    url='clarens53@gmail.com',
    py_modules=['formulas'],
)
